L1-L2 recut asset pack v2
- worker_idle.png
- worker_push.png
- cart_empty.png
- cart_water_loaded.png
- cart_cola_loaded.png
Transparent PNG assets for supermarket restock game.
